/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AlertTimelinePanel } from "@/components/dashboard/AlertTimelinePanel";
import { CurrentStateCard } from "@/components/dashboard/CurrentStateCard";
import { LogValidationPanel } from "@/components/dashboard/LogValidationPanel";
import { RULPredictionCard } from "@/components/dashboard/RULPredictionCard";
import { Sidebar } from "@/components/dashboard/Sidebar";
import { TopStatusBar } from "@/components/dashboard/TopStatusBar";
import { TrendGraph } from "@/components/dashboard/TrendGraph";
import { cn } from "@/lib/utils";
import { useEffect, useState } from "react";

// Types
interface DataPoint {
  timestamp: string;
  sensorValue: number;
  trend?: number;
  threshold?: number;
  projected?: boolean;
}

interface Alert {
  id: string;
  timestamp: string;
  component: string;
  alertLevel: "routine" | "warning" | "critical";
  rulAtTrigger: number;
  status: "active" | "resolved";
}

export default function App() {
  // State
  const [isSimulationMode, setIsSimulationMode] = useState(false);
  const [vibrationLevel, setVibrationLevel] = useState(20); // 0-100
  const [sensorData, setSensorData] = useState<DataPoint[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [lastLog, setLastLog] = useState({
    timestamp: new Date().toISOString(),
    technician: "Lt. Cmdr. Data",
    note: "Routine inspection of port turbine bearing assembly. No anomalies detected visually.",
    sensorReading: 4.2,
    validationStatus: "confirmed" as const
  });

  // Constants
  const FAILURE_THRESHOLD = 12.0;
  const WARNING_THRESHOLD = 8.0;

  // Initialize Data
  useEffect(() => {
    const initialData: DataPoint[] = [];
    const now = new Date();
    for (let i = 60; i > 0; i--) {
      const time = new Date(now.getTime() - i * 60000);
      initialData.push({
        timestamp: time.toISOString(),
        sensorValue: 4 + Math.random() * 0.5,
        trend: 4.2 + (60 - i) * 0.01,
      });
    }
    setSensorData(initialData);

    // Initial Alerts
    setAlerts([
      {
        id: "1",
        timestamp: new Date(now.getTime() - 3600000).toISOString(),
        component: "Port Turbine",
        alertLevel: "routine",
        rulAtTrigger: 45.2,
        status: "resolved"
      },
      {
        id: "2",
        timestamp: new Date(now.getTime() - 7200000).toISOString(),
        component: "Cooling Pump A",
        alertLevel: "warning",
        rulAtTrigger: 12.5,
        status: "active"
      }
    ]);
  }, []);

  // Data Simulation Loop
  useEffect(() => {
    const interval = setInterval(() => {
      setSensorData(prev => {
        const last = prev[prev.length - 1];
        const now = new Date();
        
        // Base value depends on simulation mode
        let baseValue = isSimulationMode 
          ? (vibrationLevel / 10) + (Math.random() * 0.5) 
          : 4 + (Math.random() * 0.5);

        // Add some noise
        const noise = (Math.random() - 0.5) * 0.2;
        let newValue = baseValue + noise;

        // Trend calculation
        const newTrend = (last?.trend || 4) + (isSimulationMode ? 0.05 : 0.001);

        // Keep array size manageable
        const newData = [...prev.slice(1), {
          timestamp: now.toISOString(),
          sensorValue: newValue,
          trend: newTrend
        }];

        // Check for alerts based on new value
        if (newValue > WARNING_THRESHOLD) {
          // In a real app, we'd debounce this to avoid flooding alerts
          if (Math.random() > 0.95) {
            const newAlert: Alert = {
              id: Date.now().toString(),
              timestamp: now.toISOString(),
              component: "Port Turbine",
              alertLevel: newValue > FAILURE_THRESHOLD ? "critical" : "warning",
              rulAtTrigger: calculateRUL(newValue, newTrend),
              status: "active"
            };
            setAlerts(prevAlerts => [newAlert, ...prevAlerts].slice(0, 10));
          }
        }

        return newData;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isSimulationMode, vibrationLevel]);

  // Helper Functions
  const calculateRUL = (currentValue: number, trend: number) => {
    // Simple linear extrapolation for demo
    const remaining = FAILURE_THRESHOLD - currentValue;
    const rate = 0.1; // arbitrary rate
    return Math.max(0, remaining / rate);
  };

  const handleInjectFault = () => {
    setVibrationLevel(95);
    const now = new Date();
    const newAlert: Alert = {
      id: Date.now().toString(),
      timestamp: now.toISOString(),
      component: "Port Turbine",
      alertLevel: "critical",
      rulAtTrigger: 0.5,
      status: "active"
    };
    setAlerts(prev => [newAlert, ...prev]);
    
    // Update log to reflect fault
    setLastLog({
      timestamp: now.toISOString(),
      technician: "System Automated",
      note: "CRITICAL FAULT INJECTED: Sudden vibration spike detected in main bearing assembly.",
      sensorReading: 9.5,
      validationStatus: "mismatch"
    });
  };

  // Derived State
  const currentSensorValue = sensorData[sensorData.length - 1]?.sensorValue || 0;
  const currentTrend = sensorData[sensorData.length - 1]?.trend || 0;
  const growthRate = (currentSensorValue - (sensorData[0]?.sensorValue || 0)) / (sensorData.length / 60); // per hour approx
  const rul = calculateRUL(currentSensorValue, currentTrend);
  
  const alertStatus = currentSensorValue > FAILURE_THRESHOLD ? "critical" 
    : currentSensorValue > WARNING_THRESHOLD ? "warning" 
    : "routine";

  return (
    <div className="flex h-screen bg-slate-950 text-slate-200 font-sans overflow-hidden selection:bg-cyan-500/30">
      <Sidebar 
        isSimulationMode={isSimulationMode}
        onToggleSimulation={setIsSimulationMode}
        onInjectFault={handleInjectFault}
        vibrationLevel={vibrationLevel}
        onVibrationChange={setVibrationLevel}
      />

      <div className="flex-1 flex flex-col min-w-0">
        <TopStatusBar />

        <main className="flex-1 p-6 overflow-auto">
          <div className="grid grid-cols-12 gap-6 h-full max-w-7xl mx-auto">
            
            {/* Left Column - Key Metrics */}
            <div className="col-span-12 lg:col-span-3 flex flex-col gap-6">
              <div className="h-48">
                <CurrentStateCard 
                  sensorValue={currentSensorValue}
                  growthRate={growthRate}
                  confidenceScore={0.94}
                  isStable={currentSensorValue < WARNING_THRESHOLD}
                />
              </div>
              <div className="flex-1 min-h-[200px]">
                <RULPredictionCard 
                  rulHours={rul}
                  alertStatus={alertStatus}
                />
              </div>
            </div>

            {/* Middle Column - Main Graph & Logs */}
            <div className="col-span-12 lg:col-span-6 flex flex-col gap-6">
              <div className="flex-1 min-h-[400px]">
                <TrendGraph 
                  data={sensorData}
                  threshold={FAILURE_THRESHOLD}
                />
              </div>
              <div className="h-48">
                <LogValidationPanel logEntry={lastLog} />
              </div>
            </div>

            {/* Right Column - Alerts */}
            <div className="col-span-12 lg:col-span-3 h-full min-h-[400px]">
              <AlertTimelinePanel alerts={alerts} />
            </div>

          </div>
        </main>
      </div>
    </div>
  );
}

