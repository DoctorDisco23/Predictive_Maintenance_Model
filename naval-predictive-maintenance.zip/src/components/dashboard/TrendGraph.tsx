import { Card } from "@/components/ui/Card";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { CartesianGrid, Line, LineChart, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

interface DataPoint {
  timestamp: string;
  sensorValue: number;
  trend?: number;
  threshold?: number;
  projected?: boolean;
}

interface TrendGraphProps {
  data: DataPoint[];
  threshold: number;
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-slate-900 border border-slate-800 p-3 rounded shadow-xl backdrop-blur-md">
        <p className="text-[10px] text-slate-400 font-mono mb-2">{format(new Date(label), "HH:mm:ss")}</p>
        {payload.map((entry: any, index: number) => (
          <div key={index} className="flex items-center gap-2 mb-1 last:mb-0">
            <div 
              className="w-2 h-2 rounded-full" 
              style={{ backgroundColor: entry.color }}
            />
            <span className="text-xs text-slate-300 font-medium capitalize">
              {entry.name}:
            </span>
            <span className="text-xs font-mono font-bold text-slate-100">
              {entry.value.toFixed(2)}
            </span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

export function TrendGraph({ data, threshold }: TrendGraphProps) {
  return (
    <Card title="Vibration Trend Analysis" className="h-full flex flex-col">
      <div className="flex-1 w-full min-h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
            <XAxis 
              dataKey="timestamp" 
              tick={{ fill: '#64748b', fontSize: 10, fontFamily: 'JetBrains Mono' }}
              tickFormatter={(str) => format(new Date(str), "HH:mm")}
              axisLine={{ stroke: '#334155' }}
              tickLine={false}
              minTickGap={30}
            />
            <YAxis 
              tick={{ fill: '#64748b', fontSize: 10, fontFamily: 'JetBrains Mono' }}
              axisLine={false}
              tickLine={false}
              domain={[0, 'auto']}
            />
            <Tooltip content={<CustomTooltip />} cursor={{ stroke: '#334155', strokeWidth: 1, strokeDasharray: '4 4' }} />
            
            {/* Threshold Line */}
            <ReferenceLine 
              y={threshold} 
              stroke="#ef4444" 
              strokeDasharray="3 3" 
              label={{ 
                value: 'FAILURE THRESHOLD', 
                position: 'insideTopRight', 
                fill: '#ef4444', 
                fontSize: 10,
                fontWeight: 'bold'
              }} 
            />

            {/* Historical Data */}
            <Line 
              type="monotone" 
              dataKey="sensorValue" 
              stroke="#06b6d4" 
              strokeWidth={2} 
              dot={false}
              activeDot={{ r: 4, fill: '#06b6d4', stroke: '#fff' }}
              name="Sensor"
              isAnimationActive={false}
            />

            {/* Trend Line */}
            <Line 
              type="monotone" 
              dataKey="trend" 
              stroke="#f59e0b" 
              strokeWidth={2} 
              strokeDasharray="5 5" 
              dot={false}
              name="Trend"
              isAnimationActive={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}
