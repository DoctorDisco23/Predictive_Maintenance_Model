import { Badge } from "@/components/ui/Badge";
import { Card } from "@/components/ui/Card";
import { cn } from "@/lib/utils";
import { Activity, ArrowUp, CheckCircle, ShieldCheck, TrendingUp } from "lucide-react";

interface CurrentStateCardProps {
  sensorValue: number;
  growthRate: number;
  confidenceScore: number;
  isStable: boolean;
}

export function CurrentStateCard({ sensorValue, growthRate, confidenceScore, isStable }: CurrentStateCardProps) {
  return (
    <Card title="Current State" className="h-full">
      <div className="grid grid-cols-2 gap-4 h-full">
        <div className="flex flex-col justify-between">
          <div>
            <span className="text-[10px] text-slate-500 uppercase tracking-wider font-bold">Vibration</span>
            <div className="flex items-baseline gap-1 mt-1">
              <span className="text-3xl font-mono font-bold text-slate-100">{sensorValue.toFixed(2)}</span>
              <span className="text-xs text-slate-400 font-mono">mm/s</span>
            </div>
          </div>
          
          <div className="mt-4">
            <span className="text-[10px] text-slate-500 uppercase tracking-wider font-bold">Growth Rate</span>
            <div className="flex items-center gap-1 mt-1 text-amber-500">
              <TrendingUp className="h-3 w-3" />
              <span className="text-sm font-mono font-bold">+{growthRate.toFixed(2)}</span>
              <span className="text-[10px] text-slate-400 ml-1">/hr</span>
            </div>
          </div>
        </div>

        <div className="flex flex-col justify-between items-end text-right">
          <div>
            <span className="text-[10px] text-slate-500 uppercase tracking-wider font-bold block mb-1">Status</span>
            <Badge status={isStable ? "healthy" : "warning"} size="sm">
              {isStable ? "STABLE" : "NOISY"}
            </Badge>
          </div>

          <div className="mt-4 w-full flex flex-col items-end">
            <span className="text-[10px] text-slate-500 uppercase tracking-wider font-bold mb-1">Confidence</span>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div 
                className="h-full bg-cyan-500 rounded-full transition-all duration-500"
                style={{ width: `${confidenceScore * 100}%` }}
              />
            </div>
            <span className="text-[10px] font-mono text-cyan-400 mt-1">{(confidenceScore * 100).toFixed(0)}%</span>
          </div>
        </div>
      </div>
    </Card>
  );
}
