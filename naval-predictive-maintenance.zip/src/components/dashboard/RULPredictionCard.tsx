import { Badge } from "@/components/ui/Badge";
import { Card } from "@/components/ui/Card";
import { cn } from "@/lib/utils";
import { AlertCircle, CheckCircle, Clock, ShieldAlert } from "lucide-react";

interface RULPredictionCardProps {
  rulHours: number;
  alertStatus: "routine" | "warning" | "critical";
}

export function RULPredictionCard({ rulHours, alertStatus }: RULPredictionCardProps) {
  const statusConfig = {
    routine: {
      color: "text-emerald-400",
      bg: "bg-emerald-500/5",
      border: "border-emerald-500/20",
      icon: CheckCircle,
      label: "ROUTINE",
      badgeStatus: "healthy" as const
    },
    warning: {
      color: "text-amber-400",
      bg: "bg-amber-500/5",
      border: "border-amber-500/20",
      icon: AlertCircle,
      label: "WARNING",
      badgeStatus: "warning" as const
    },
    critical: {
      color: "text-red-400",
      bg: "bg-red-500/10",
      border: "border-red-500/30",
      icon: ShieldAlert,
      label: "CRITICAL",
      badgeStatus: "critical" as const
    }
  };

  const config = statusConfig[alertStatus];
  const Icon = config.icon;

  return (
    <Card 
      title="RUL Prediction" 
      className={cn(
        "h-full relative overflow-hidden transition-colors duration-500",
        config.bg,
        config.border
      )}
    >
      <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
        <Icon className={cn("w-32 h-32", config.color)} />
      </div>

      <div className="flex flex-col items-center justify-center h-full py-2 z-10 relative">
        <span className="text-xs text-slate-400 uppercase tracking-widest font-bold mb-2">Estimated Life</span>
        
        <div className="flex items-baseline gap-2 mb-4">
          <span className={cn("text-5xl font-mono font-bold tracking-tighter", config.color)}>
            {rulHours.toFixed(1)}
          </span>
          <span className="text-sm text-slate-500 font-mono uppercase">Hours</span>
        </div>

        <Badge status={config.badgeStatus} size="lg" className="px-4 py-1.5 shadow-lg backdrop-blur-md">
          <span className="flex items-center gap-2">
            <Icon className="w-4 h-4" />
            {config.label}
          </span>
        </Badge>

        <div className="mt-6 w-full px-8">
          <div className="flex justify-between text-[10px] text-slate-500 uppercase font-bold mb-1">
            <span>Confidence Interval</span>
            <span>95%</span>
          </div>
          <div className="w-full bg-slate-900/50 h-1.5 rounded-full overflow-hidden border border-slate-800">
            <div className="h-full w-full flex items-center justify-center relative">
              {/* Range indicator */}
              <div 
                className={cn("absolute h-full rounded-full opacity-50", config.color.replace('text-', 'bg-'))}
                style={{ width: '30%', left: '35%' }}
              />
              {/* Center point */}
              <div 
                className={cn("absolute h-2 w-0.5 rounded-full", config.color.replace('text-', 'bg-'))}
                style={{ left: '50%' }}
              />
            </div>
          </div>
          <div className="flex justify-between text-[10px] font-mono text-slate-600 mt-1">
            <span>{(rulHours * 0.8).toFixed(1)}h</span>
            <span>{(rulHours * 1.2).toFixed(1)}h</span>
          </div>
        </div>
      </div>
    </Card>
  );
}
