import { Badge } from "@/components/ui/Badge";
import { cn } from "@/lib/utils";
import { Activity, AlertTriangle, CheckCircle2, Clock, ShieldAlert } from "lucide-react";
import { useEffect, useState } from "react";

export function TopStatusBar() {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <header className="h-14 bg-slate-900 border-b border-slate-800 flex items-center justify-between px-4 z-50 relative">
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 bg-cyan-500/10 rounded flex items-center justify-center border border-cyan-500/20">
            <Activity className="h-5 w-5 text-cyan-400" />
          </div>
          <div>
            <h1 className="text-sm font-bold text-slate-100 tracking-wider uppercase">Naval Command</h1>
            <p className="text-[10px] text-slate-400 font-mono">FLEET MONITORING SYSTEM v2.4</p>
          </div>
        </div>

        <div className="h-8 w-px bg-slate-800" />

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 uppercase tracking-wider">Fleet Health</span>
            <Badge status="healthy" size="sm" className="gap-1.5">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              OPTIMAL
            </Badge>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-6">
        <div className="flex gap-4">
          <div className="flex items-center gap-2 px-3 py-1 bg-amber-500/5 border border-amber-500/10 rounded">
            <AlertTriangle className="h-4 w-4 text-amber-500" />
            <div className="flex flex-col leading-none">
              <span className="text-[10px] text-amber-500/70 uppercase">Warning</span>
              <span className="text-sm font-mono font-bold text-amber-500">2</span>
            </div>
          </div>
          
          <div className="flex items-center gap-2 px-3 py-1 bg-red-500/5 border border-red-500/10 rounded">
            <ShieldAlert className="h-4 w-4 text-red-500" />
            <div className="flex flex-col leading-none">
              <span className="text-[10px] text-red-500/70 uppercase">Critical</span>
              <span className="text-sm font-mono font-bold text-red-500">0</span>
            </div>
          </div>
        </div>

        <div className="h-8 w-px bg-slate-800" />

        <div className="flex items-center gap-2 text-slate-400 font-mono text-xs">
          <Clock className="h-4 w-4" />
          <span>
            {time.toLocaleTimeString('en-US', { 
              hour12: false, 
              hour: '2-digit', 
              minute: '2-digit', 
              second: '2-digit' 
            })} UTC
          </span>
        </div>
      </div>
    </header>
  );
}
