import { Badge } from "@/components/ui/Badge";
import { Card } from "@/components/ui/Card";
import { cn } from "@/lib/utils";
import { CheckCircle, FileText, ShieldAlert, ShieldCheck } from "lucide-react";

interface LogValidationPanelProps {
  logEntry: {
    timestamp: string;
    technician: string;
    note: string;
    sensorReading: number;
    validationStatus: "confirmed" | "mismatch" | "filtered";
  };
}

export function LogValidationPanel({ logEntry }: LogValidationPanelProps) {
  const statusConfig = {
    confirmed: {
      color: "text-emerald-400",
      bg: "bg-emerald-500/10",
      icon: CheckCircle,
      label: "Confirmed by telemetry",
      badgeStatus: "healthy" as const
    },
    mismatch: {
      color: "text-red-400",
      bg: "bg-red-500/10",
      icon: ShieldAlert,
      label: "Mismatch detected",
      badgeStatus: "critical" as const
    },
    filtered: {
      color: "text-amber-400",
      bg: "bg-amber-500/10",
      icon: ShieldCheck,
      label: "Trial/Test mode – filtered",
      badgeStatus: "warning" as const
    }
  };

  const config = statusConfig[logEntry.validationStatus];
  const Icon = config.icon;

  return (
    <Card title="Log & Sensor Validation" className="h-full">
      <div className="space-y-4">
        <div className="flex items-start gap-4">
          <div className="flex-shrink-0 w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center border border-slate-700">
            <FileText className="w-4 h-4 text-slate-400" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold text-slate-200">{logEntry.technician}</span>
              <span className="text-[10px] text-slate-500 font-mono">{logEntry.timestamp}</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed bg-slate-900/50 p-3 rounded border border-slate-800/50 font-mono">
              "{logEntry.note}"
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 pt-4 border-t border-slate-800/50">
          <div>
            <span className="text-[10px] text-slate-500 uppercase font-bold block mb-1">Sensor Reading</span>
            <div className="flex items-baseline gap-1">
              <span className="text-lg font-mono font-bold text-slate-200">{logEntry.sensorReading.toFixed(2)}</span>
              <span className="text-[10px] text-slate-500 font-mono">mm/s</span>
            </div>
          </div>
          
          <div className="flex flex-col items-end">
            <span className="text-[10px] text-slate-500 uppercase font-bold block mb-1">Validation Result</span>
            <Badge status={config.badgeStatus} size="sm" className="gap-1.5 w-full justify-center">
              <Icon className="w-3 h-3" />
              {config.label}
            </Badge>
          </div>
        </div>
      </div>
    </Card>
  );
}
