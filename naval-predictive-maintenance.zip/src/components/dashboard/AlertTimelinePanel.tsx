import { Badge } from "@/components/ui/Badge";
import { Card } from "@/components/ui/Card";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { AlertTriangle, CheckCircle, ShieldAlert } from "lucide-react";

interface Alert {
  id: string;
  timestamp: string;
  component: string;
  alertLevel: "routine" | "warning" | "critical";
  rulAtTrigger: number;
  status: "active" | "resolved";
}

interface AlertTimelinePanelProps {
  alerts: Alert[];
}

export function AlertTimelinePanel({ alerts }: AlertTimelinePanelProps) {
  return (
    <Card title="Alert Timeline" className="h-full flex flex-col">
      <div className="flex-1 overflow-auto -mx-4">
        <table className="w-full text-left border-collapse">
          <thead className="bg-slate-900/80 sticky top-0 z-10 backdrop-blur-md">
            <tr>
              <th className="px-4 py-2 text-[10px] font-bold text-slate-500 uppercase tracking-wider border-b border-slate-800">Time</th>
              <th className="px-4 py-2 text-[10px] font-bold text-slate-500 uppercase tracking-wider border-b border-slate-800">Component</th>
              <th className="px-4 py-2 text-[10px] font-bold text-slate-500 uppercase tracking-wider border-b border-slate-800">Level</th>
              <th className="px-4 py-2 text-[10px] font-bold text-slate-500 uppercase tracking-wider border-b border-slate-800 text-right">RUL</th>
              <th className="px-4 py-2 text-[10px] font-bold text-slate-500 uppercase tracking-wider border-b border-slate-800 text-center">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/50">
            {alerts.map((alert) => (
              <tr key={alert.id} className="hover:bg-slate-800/30 transition-colors">
                <td className="px-4 py-3 text-xs font-mono text-slate-400 whitespace-nowrap">
                  {format(new Date(alert.timestamp), "HH:mm:ss")}
                </td>
                <td className="px-4 py-3 text-xs font-medium text-slate-200">
                  {alert.component}
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-1.5">
                    {alert.alertLevel === "critical" && <ShieldAlert className="w-3 h-3 text-red-500" />}
                    {alert.alertLevel === "warning" && <AlertTriangle className="w-3 h-3 text-amber-500" />}
                    {alert.alertLevel === "routine" && <CheckCircle className="w-3 h-3 text-emerald-500" />}
                    <span 
                      className={cn(
                        "text-[10px] font-bold uppercase tracking-wider",
                        alert.alertLevel === "critical" ? "text-red-400" :
                        alert.alertLevel === "warning" ? "text-amber-400" :
                        "text-emerald-400"
                      )}
                    >
                      {alert.alertLevel}
                    </span>
                  </div>
                </td>
                <td className="px-4 py-3 text-xs font-mono text-slate-400 text-right">
                  {alert.rulAtTrigger.toFixed(1)}h
                </td>
                <td className="px-4 py-3 text-center">
                  <Badge 
                    status={alert.status === "active" ? "warning" : "healthy"} 
                    size="sm"
                    className="w-20"
                  >
                    {alert.status}
                  </Badge>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}
