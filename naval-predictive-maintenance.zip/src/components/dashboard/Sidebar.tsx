import { cn } from "@/lib/utils";
import { Activity, AlertTriangle, BarChart3, ChevronDown, Cog, Database, LayoutDashboard, Settings, Sliders, Zap } from "lucide-react";
import React, { ReactElement, ReactNode, useState } from "react";

interface SidebarProps {
  isSimulationMode: boolean;
  onToggleSimulation: (value: boolean) => void;
  onInjectFault: () => void;
  vibrationLevel: number;
  onVibrationChange: (value: number) => void;
}

export function Sidebar({ 
  isSimulationMode, 
  onToggleSimulation, 
  onInjectFault,
  vibrationLevel,
  onVibrationChange
}: SidebarProps) {
  const [selectedComponent, setSelectedComponent] = useState("port-turbine");

  const components = [
    { id: "port-turbine", name: "Port Turbine" },
    { id: "starboard-turbine", name: "Starboard Turbine" },
    { id: "main-bearing", name: "Main Bearing #1" },
    { id: "cooling-pump", name: "Cooling Pump A" },
    { id: "generator", name: "Generator Unit" },
  ];

  return (
    <aside className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col h-full z-40">
      <div className="p-4 border-b border-slate-800">
        <label className="text-[10px] uppercase text-slate-500 font-bold tracking-wider mb-2 block">
          Select Component
        </label>
        <div className="relative">
          <select
            value={selectedComponent}
            onChange={(e) => setSelectedComponent(e.target.value)}
            className="w-full bg-slate-800 text-slate-200 text-xs font-mono border border-slate-700 rounded p-2 pr-8 appearance-none focus:outline-none focus:ring-1 focus:ring-cyan-500"
          >
            {components.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
          <ChevronDown className="absolute right-2 top-2.5 h-4 w-4 text-slate-500 pointer-events-none" />
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-1">
        <NavItem icon={<LayoutDashboard />} label="Dashboard" active />
        <NavItem icon={<BarChart3 />} label="Analytics" />
        <NavItem icon={<Database />} label="Data Logs" />
        <NavItem icon={<Settings />} label="Configuration" />
      </nav>

      <div className="p-4 border-t border-slate-800 bg-slate-900/50">
        <div className="flex items-center justify-between mb-4">
          <span className="text-[10px] uppercase text-slate-500 font-bold tracking-wider">
            System Mode
          </span>
          <div 
            className={cn(
              "px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider border",
              isSimulationMode 
                ? "bg-amber-500/10 text-amber-500 border-amber-500/20" 
                : "bg-emerald-500/10 text-emerald-500 border-emerald-500/20"
            )}
          >
            {isSimulationMode ? "SIMULATION" : "LIVE"}
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between bg-slate-800 p-1 rounded-lg">
            <button
              onClick={() => onToggleSimulation(false)}
              className={cn(
                "flex-1 py-1.5 text-xs font-medium rounded-md transition-all",
                !isSimulationMode 
                  ? "bg-emerald-600 text-white shadow-sm" 
                  : "text-slate-400 hover:text-slate-200"
              )}
            >
              Live
            </button>
            <button
              onClick={() => onToggleSimulation(true)}
              className={cn(
                "flex-1 py-1.5 text-xs font-medium rounded-md transition-all",
                isSimulationMode 
                  ? "bg-amber-600 text-white shadow-sm" 
                  : "text-slate-400 hover:text-slate-200"
              )}
            >
              Sim
            </button>
          </div>

          {isSimulationMode && (
            <div className="space-y-3 pt-2 border-t border-slate-800/50 animate-in fade-in slide-in-from-top-2 duration-200">
              <div>
                <div className="flex justify-between mb-1">
                  <label className="text-[10px] text-slate-400 uppercase">Vibration Load</label>
                  <span className="text-[10px] font-mono text-amber-500">{vibrationLevel}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={vibrationLevel}
                  onChange={(e) => onVibrationChange(parseInt(e.target.value))}
                  className="w-full h-1 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-amber-500"
                />
              </div>

              <button
                onClick={onInjectFault}
                className="w-full flex items-center justify-center gap-2 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-500 text-xs font-bold py-2 rounded transition-colors uppercase tracking-wider"
              >
                <Zap className="h-3 w-3" />
                Inject Fault
              </button>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
}

function NavItem({ icon, label, active = false }: { icon: ReactNode; label: string; active?: boolean }) {
  return (
    <button
      className={cn(
        "w-full flex items-center gap-3 px-3 py-2 rounded-md text-xs font-medium transition-colors",
        active 
          ? "bg-cyan-500/10 text-cyan-400 border border-cyan-500/20" 
          : "text-slate-400 hover:bg-slate-800 hover:text-slate-200 border border-transparent"
      )}
    >
      {React.cloneElement(icon as ReactElement, { className: "h-4 w-4" })}
      {label}
    </button>
  );
}
