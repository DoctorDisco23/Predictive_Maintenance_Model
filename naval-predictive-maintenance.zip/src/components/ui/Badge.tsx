import { cn } from "@/lib/utils";
import { ReactNode } from "react";

type Status = "healthy" | "warning" | "critical" | "info" | "neutral";

interface BadgeProps {
  status: Status;
  children: ReactNode;
  className?: string;
  size?: "sm" | "md" | "lg";
}

export function Badge({ status, children, className, size = "md" }: BadgeProps) {
  const variants = {
    healthy: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
    warning: "bg-amber-500/10 text-amber-400 border-amber-500/20",
    critical: "bg-red-500/10 text-red-400 border-red-500/20",
    info: "bg-cyan-500/10 text-cyan-400 border-cyan-500/20",
    neutral: "bg-slate-500/10 text-slate-400 border-slate-500/20",
  };

  const sizes = {
    sm: "text-[10px] px-1.5 py-0.5",
    md: "text-xs px-2 py-1",
    lg: "text-sm px-3 py-1.5",
  };

  return (
    <span
      className={cn(
        "inline-flex items-center justify-center rounded border font-medium uppercase tracking-wider font-mono",
        variants[status],
        sizes[size],
        className
      )}
    >
      {children}
    </span>
  );
}
