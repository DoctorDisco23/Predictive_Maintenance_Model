import { cn } from "@/lib/utils";
import { HTMLAttributes, ReactNode } from "react";

interface CardProps extends HTMLAttributes<HTMLDivElement> {
  title?: string;
  action?: ReactNode;
  children?: ReactNode;
  className?: string;
}

export function Card({ title, action, children, className, ...props }: CardProps) {
  return (
    <div
      className={cn(
        "bg-slate-900/50 border border-slate-800 rounded-lg overflow-hidden backdrop-blur-sm",
        className
      )}
      {...props}
    >
      {(title || action) && (
        <div className="px-4 py-3 border-b border-slate-800 flex justify-between items-center bg-slate-900/80">
          {title && (
            <h3 className="text-xs font-medium text-slate-400 uppercase tracking-wider font-mono">
              {title}
            </h3>
          )}
          {action && <div>{action}</div>}
        </div>
      )}
      <div className="p-4">{children}</div>
    </div>
  );
}
